/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on July 9, 2015, 1:04 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

