/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 8, 2015, 10:08 AM
 * Purpose: Ocean Levels
 */
//System Libraries
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
 
//Function Prototypes

//Execute
int main(int argc, char** argv) {
    //Declare Variables
    float ocnRise=1.5f;         //Ocean Rises 1.5 mm per year
    unsigned short year=1;      //year of ocean's rise
    float sum;                  //total ocean rise
    
    //Loop of Ocean Rise
    do  {
    //Calculations    
    sum=ocnRise*year;
    //Output Results
    cout<<fixed<<showpoint<<setprecision(1);
    cout<<"The Ocean will rise "<<sum<<"mm in "<<year<<" year(s)."<<endl;
    year++;
    }while(year<26);{           //Up to 25 years      
    }
    
    return 0;
}

