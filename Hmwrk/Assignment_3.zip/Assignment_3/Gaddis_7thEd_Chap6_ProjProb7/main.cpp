/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 9, 2015, 1:52 PM
 * Purpose: Given date output the day of the week
 */
//System Libraries
#include <iostream>
#include <cstring>
#include <cmath>
#include <iomanip>
using namespace std;
//User Libraries

//Global Constants

//Function Prototypes
float ftoc(float);
float ftcIntrp(float,float,float,float,float);

//Execution
int main(int argc, char** argv) {
    //Declare variables
    float f1=32.0f,f2=212.0f,c1=0.0f,c2=100.0f;
    
    //loop and output the variables
    cout<<"  Fahrenheit";
    cout<<"   Celsius";
    cout<<"   Celsius"<<endl;
    for(float fahren=f1;fahren<=f2;fahren++){
        cout<<fixed<<showpoint<<setprecision(2);
        cout<<setw(10)<<fahren;
        cout<<setw(10)<<ftoc(fahren);
        cout<<setw(10)<<ftcIntrp(fahren,f1,f2,c1,c2);
        cout<<endl;
    }
    
    return 0;
}

float ftoc(float f){
    return 5.0f/9*(f-32);
}

float ftcIntrp(float f,float f1,float f2,float c1,float c2){
    return c1+(c2-c1)*(f-f1)/(f2-f1);
}



