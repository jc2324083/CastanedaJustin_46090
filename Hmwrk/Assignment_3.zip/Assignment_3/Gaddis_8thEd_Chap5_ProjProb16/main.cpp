/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 9, 2015, 11:06 AM
 * Purpose: Given date output the day of the week
 */
//System Libraries
#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;
//User Libraries

//Global Constants

//Function Prototypes
bool isLpYr(unsigned short);
int gtMnVal();
string dayOfWk(string,short,unsigned short);

//Execution
int main(int argc, char** argv) {
    unsigned short year;
    string month;
    const int SIZE=4;
    char rday[SIZE];
    char day[SIZE-1];
    short nDay;
    
    //Input the date
    cout<<"Input date form of July 4, 2008"<<endl;
    cin>>month;
    cin>>rday;
    cin>>year;
    
    
    if(strlen(rday)==3){
        day[0]=rday[0];
        day[1]=rday[1];
        day[2]='\0';
    }

    return 0;
}

string dayOfWk(string mn,short day,unsigned short){
    //Declare Variable
    char numDay=(day+gtMnVal(mn,yer)+gtYrVal(yr)+gtCntVl(yr)%7);
}

int gtCntry(unsigned short year){
    return 2*(3-year/100%4);
}

int gtYrVal(unsigned short year){
    //Declare variables
    char part1,part2;
}

bool isLpYr(unsigned short year){
    return ((year%400==0)||((year%4==0)&&!(year%100==0)));
}