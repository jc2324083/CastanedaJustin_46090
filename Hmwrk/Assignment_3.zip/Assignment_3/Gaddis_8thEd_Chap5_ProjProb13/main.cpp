/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 9, 2015, 10:28 AM
 * Purpose: The Greatest and Least of These
 */
//System Libraries
#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;
//User Libraries

//Global Constants

//Function Prototypes

//Execution
int main(int argc, char** argv) {
    //Declare and Initialize Variables
    int integer;                //User integer
    int min=100;                    //smallest number
    int max=1;                    //largest number
    
    do{
        cout<<"Enter any number between 1 and 100. Enter -99 to end program...";
            cin>>integer;
        if (integer<min);
        {
            min=integer;
            
        }if(integer>max);{
        
            max=integer;
                           }
                                       
        
    }while(integer!=-99);{
        
        cout<<"Thank you!"<<endl;
    }
cout<<"The highest number is "<<max<<endl;
        cout<<"The lowest number is "<<min<<endl;
    return 0;
}

