/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 9, 2015, 11:06 AM
 * Purpose: Given date output the day of the week
 */
//System Libraries
#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;
//User Libraries

//Global Constants

//Function Prototypes
bool isLpYr(unsigned short);
int gtMnVal();
string dayOfWk(string,short,unsigned short);
int atoiLk(char[]);

//Execution
int main(int argc, char** argv) {
    //Declare variables
    unsigned short year;
    string month;
    const int SIZE=4;
    char rday[SIZE];
    short nDay;
    
    //Input the date
    cout<<"Input date form of July 4, 2008"<<endl;
    cin>>month;
    cin>>rday;
    cin>>year;
    
    //Translate
    nDay=atoiLk(rday);
    
    //Your day corresponding to the date is
    cout<<"Day = "<<dayOfWk(month,nDay,year)<<endl;
    
    //Exit!
    return 0;
}

string dayOfWk(string mn,short day,unsigned short yr){
    //Declare Variable
    char numDay=(day+gtMnVal(mn,yr)+gtYrVal(yr)+gtCntVl(yr)%7);
}

int gtCntry(unsigned short year){
    return 2*(3-year/100%4);
}

int gtYrVal(unsigned short year){
    //Declare variables
    char part1,part2;
}

bool isLpYr(unsigned short year){
    return ((year%400==0)||((year%4==0)&&!(year%100==0)));
}

int atoiLk(char n[]){
    //Declare Variable
    int number=n[0]-48;
    for(int i=1;i<=strlen(n)-2;i++){
        number=number*10+[i]-48;
    }
    return number;
}