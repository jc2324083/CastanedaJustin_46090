/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 24, 2015, 9:59 AM
 * Purpose: Ocean Levels
 */

#include <iostream>

using namespace std;
// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{
    //Declare and Initialize Variables
    float ocnRise;      //ocnRise = Ocean levels rising per year
    float years;        //amount of years that have passed
    float ocnLvl;       //ocnLvl = total ocean level
    ocnRise = 1.5;      //units in millimeters
    years = 5;          //years to calculate ocean rise
    
    //Calculations for 5 years
    ocnLvl= ocnRise*years; // Ocean rising rate multiplied by number of years
    
    //Output
    cout<<"In 5 years the ocean level will be "<<ocnLvl<<" millimeters higher."<<endl;
    
    //Calculations for 7 years
    years = 7;
    ocnLvl = ocnRise*years; 
    
    //Output
    cout<<"In 7 years the ocean level will be "<<ocnLvl<<" millimeters higher."<<endl;
    
    //Calculations for 10 years
    years = 10;
    ocnLvl=ocnRise*years;
    
    //Output
     cout<<"In 10 years the ocean level will be "<<ocnLvl<<" millimeters higher."<<endl;
     
    return 0;
}

