/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 23, 2015, 10:18 AM
 * Purpose: Restaurant Bill
 */

#include <iostream>
using namespace std;
// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{  
    // Problem 4
    // Declare and Initialize Variables
    float meal;         //The cost of the meal
    float mealTax;      //Tax on the meal
    float tip;          //percentage of tip
    float total;        //complete total of everything
    float tpTotal;      // cost of tip
    float mlTotal;      //cost of the meal with tax
    
    meal = 88.67f;
    mealTax = 0.0675f;
    tip = 0.20f;
    
    //Calculations
    mlTotal = meal * mealTax;
    tpTotal = meal * tip;
    total = meal + mlTotal + tpTotal;
    
    //Output
    cout << "The cost of the meal is $"<<meal<<endl;
    cout << "The cost of tax is $"<<mlTotal<<endl;
    cout << "The recommended tip is $"<<tpTotal<<endl;
    cout << "Total amount is $"<<total<< endl;
 
    
    return 0;
}

