/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 24, 2015, 9:59 AM
 * Purpose: Personal Information
 */

#include <iostream>

using namespace std;
// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{
    //Declare and Initialize Variables
    
    // Calculations
    
    // Output
    cout<<"Justin Castaneda"<<endl<<"5214 Contay Way, Riverside CA, 92509"<<endl<<"555-2345"<<endl<<"Astrophysics"<<endl;
    
    return 0;
}

