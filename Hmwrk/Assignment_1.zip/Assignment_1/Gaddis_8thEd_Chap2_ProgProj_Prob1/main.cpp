/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 23, 2015, 10:18 AM
 * Purpose: Sum of Two Numbers
 */

#include <iostream>
using namespace std;
// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{
    // Problem 1
    //Declare Variables
    float num1;         //first number
    float num2;         //second number
    float total;        //sum of the two numbers
    
    //Input Values
    num1 = 50.0f;
    num2 = 100.0f;
    
    //Calculations
    total = num1 + num2;
    
    //Output
    cout << "The sum of " << num1 << " and " << num2 << " is " << total <<endl;
   
    return 0;
}

