/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 23, 2015, 10:18 AM
 * Purpose: Sales Prediction
 */

#include <iostream>
using namespace std;
// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{
    // Problem 2
    
    //Declare and Initialize Variables
    float prcnt;        //percent
    float sales;        //$ of sales
    float estcstd;      //East Coast Division
    prcnt = 0.58f;
    sales = 8.6f;
    
    //Calculation
    estcstd = prcnt * sales;
    
    //Output
    cout << "East Coast division will generate $"<< estcstd <<" million this year." << endl;
    
            
    return 0;
}

