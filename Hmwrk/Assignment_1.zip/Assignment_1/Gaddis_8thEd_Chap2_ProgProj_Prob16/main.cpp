/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 24, 2015, 9:59 AM
 * Purpose: Diamond Pattern
 */

#include <iostream>

using namespace std;
// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{
    //Declare and Initialize Variables
    
    // Calculations
    
    // Output
    
    cout<<"   *   "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" ***** "<<endl;
    cout<<"*******"<<endl;
    cout<<" ***** "<<endl;
    cout<<"  ***  "<<endl;
    cout<<"   *   "<<endl;
     
    return 0;
}

