/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 23, 2015, 10:18 AM
 * Purpose: Sales Tax
 */

#include <iostream>
using namespace std;
// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{  
    // Problem 3
    //Declare and Initialize Variables
    float stattx;       //State Tax
    float fdrltx;       //Federal Tax
    float sales;        //price on item purchased
    sales = 95.0f;
    
    //Calculations
    stattx = 0.04f * sales;
    fdrltx = 0.02f * sales;
    
    //Output
    cout << "The state sale tax on the $95 purchase is $" << stattx <<endl;
    cout << "The federal sale tax on the $95 purchase is $"<<fdrltx<<endl;
    
    return 0;
}

