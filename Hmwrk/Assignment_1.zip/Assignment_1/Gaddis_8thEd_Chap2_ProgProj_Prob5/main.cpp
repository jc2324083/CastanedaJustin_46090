/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 23, 2015, 10:18 AM
 * Purpose: Average of Values
 */

#include <iostream>
using namespace std;
// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{  
    // Problem 5
    //Declare and Initialize Variables
    float value1=28;    //first value
    float value2=32;    //second value
    float value3=37;    //third value
    float value4=24;    //fourth value
    float value5=33;    //fifth value
    float sum;          //the sum of all values
    float average;      //the average of the values
    
    //Calculations
    sum = value1+value2+value3+value4+value5;
    average = sum / 5;
    
    //Output
    cout << "The average of the 5 values is "<<average<<endl;
    
    return 0;
}

