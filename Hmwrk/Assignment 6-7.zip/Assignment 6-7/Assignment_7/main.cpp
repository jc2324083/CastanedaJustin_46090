/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 23, 2015, 2:38 PM
 * Purpose: Assignment 8
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
void Menu();
int getN();
void def(int);
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();
void problem6();
void problem7();
void ftion(int [],int,int);
void srtArray(int [], int);
void prntAry(const int [], int);
int bSearch(const int [], int, int);

//Execution begins here
int main(int argv,char *argc[]){
    int inN;
    do{
        Menu();
        inN=getN();
        switch(inN){
        case 1: problem1();break;
        case 2: problem2();break;
        case 3: problem3();break;
        case 4: problem4();break;
        case 5: problem5();break;
        case 6: problem6();break;
        case 7: problem7();break;
            default:;
        };
    }while(inN<8);
    return 0;
}

//Menu Function
void Menu(){
    cout<<"Type 1 for problem 1"<<endl;
    cout<<"Type 2 for problem 2"<<endl;
    cout<<"Type 3 for problem 3"<<endl;
    cout<<"Type 4 for problem 4"<<endl;
    cout<<"Type 5 for problem 5"<<endl;
    cout<<"Type 6 for problem 6"<<endl;
    cout<<"Type 7 for problem 7"<<endl;
    cout<<"Type 8 to exit \n"<<endl;
}

//Choose problem number function
int getN(){
    int inN;
    cin>>inN;
    return inN;
}

//Solution to problem 1
void problem1(){
    cout<<"Gaddis 8thED Chap 8 problem # 1"<<endl<<endl;
    
    
    //Initialize array
    const int SIZE=18;
    unsigned int account[SIZE]={5658845,4520125,7895122,8777541,
                                8451277,1302850,8080152,4562555,
                                5552012,5050552,7825877,1250255,
                                1005231,6545231,3852085,7576651,
                                7881200,4581002};
    
    //declare variables
    unsigned int number;
    bool found=false;
    
    //number input
    cout<<"Enter account number: ";
    cin>>number;
    //Number found
    for(int i=0;i<SIZE;i++){
        if(account[i]==number){
            cout<<number<<" was valid"<<endl;
            found=true;
        }
    }
    //Number not found
    if(!found){
        cout<<number<<" is invalid"<<endl<<endl;
    }

}

//Solution to problem 2
void problem2(){
    cout<<"Gaddis 8thEd Chap 8 problem # 2"<<endl<<endl;
    
    const int SIZE=10;
    int lottery[SIZE]={13579,26791,26792,33445,55555,
                      62483,77777,79422,85647,93121},
        number[SIZE];
    
    //Input
    cout<<"Enter your 10 lucky 5-digit numbers"<<endl;
    for(int i=0;i<SIZE;i++){
        cout<<"Number "<<i+1<<": ";
        cin>>number[i];
    }
    
    bool found=false;
    for(int i=0;i<SIZE;i++){
        for(int j=0;j<SIZE;j++){
            if(number[i]==lottery[j]){      //Found winning number
                cout<<number[i]<<" is a winning number!"<<endl;
                found=true;
            }
        }
    }
    //losing number
    if(!found){
        cout<<"You did not enter a winning number. Maybe next time."<<endl<<endl;
    }
}

//Solution to problem 3
void problem3(){
    cout<<"In problem # 3"<<endl<<endl;
    
}

//Solution to problem 4
void problem4(){
    cout<<"Gaddis 7thEd Chap8 problem # 4"<<endl<<endl;
    
    //Declare Variables
    const int SIZE = 18;


    // Array with customer charge accounts.
    int acntNum[SIZE] = {5658845, 4520125, 7895122, 8777541, 8451277, 1302850,
                                           8080152, 4562555, 5552012, 5050552, 7825877, 1250255,
                                           1005231, 6545231, 3852085, 7576651, 7881200, 4581002};
    // Sort the values.
    srtArray(acntNum, 18);

    // Display them again.
    cout << "The sorted values are:\n";
    prntAry(acntNum, 18);	

    int  results; // To hold the search results
    int custNum ; // To hold a new customer charge account number

    // Get a new customer charge account number to search for.
    cout << "Enter the new customer charge account number (7 digits) : ";
    cin >> custNum;

    // Search for the code.
    results = bSearch(acntNum, SIZE, custNum);

    // If srch_results contains -1 the code was not found.
    if (results == -1)
    cout << "The number does not exist in the array.\n";
    else
    {

    cout << "That ID is found at element " << results;
    cout << " in the array.\n";
    }

 }

//Solution to problem 5
void problem5(){
    cout<<"In problem # 5"<<endl<<endl;
    
}

//Solution to problem 6
void problem6(){
    cout<<"In problem # 6"<<endl<<endl;
    
}

//Solution to problem 7
void problem7(){
    cout<<"In problem # 7"<<endl<<endl;
    
}

//Exit Comment
void def(int inN){
    cout<<"You typed "<<inN<<" to exit the program"<<endl;
}
int bSearch(const int array[], int size, int value)
 {
    int first = 0, // First array element
    last = size - 1, // Last array element
    middle, // Midpoint of search
    position = -1; // Position of search value
    bool found = false; // Flag for match

    while (!found && first <= last)
    {
    middle = (first + last) / 2; // Calculate midpoint
        if (array[middle] == value) // If value is found at mid
        {
            found = true;
            position = middle;
        }
        else if (array[middle] > value) // If value is in lower half
            last = middle - 1;
        else
            first = middle + 1; // If value is in upper half
        }
 return position;
 }

void srtArray(int array[], int size)
 {
    bool swap;
    int temp;

    do
    {
        swap = false;
    for (int count = 0; count < (size - 1); count++)
    {
    if (array[count] > array[count + 1])
    {
        temp = array[count];
        array[count] = array[count + 1];
        array[count + 1] = temp;
        swap = true;
    }
    }
 } while (swap);
 }
 
 void prntAry(const int array[], int size)
 {
    for (int count = 0; count < size; count++){
    cout << array[count] << " ";
    cout << endl;
    }
 }
