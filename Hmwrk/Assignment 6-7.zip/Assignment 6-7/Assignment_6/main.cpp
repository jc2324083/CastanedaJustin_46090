/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 22, 2015, 12:20 PM
 * Purpose: Assignment 6 HW
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes
void Menu();
int getN();
void def(int);
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();
void problem6();
void problem7();
void fnctn(int [],int, int);

//Execution begins here
int main(int argv,char *argc[]){
    int inN;
    do{
        Menu();
        inN=getN();
        switch(inN){
        case 1: problem1();break;
        case 2: problem2();break;
        case 3: problem3();break;
        case 4: problem4();break;
        case 5: problem5();break;
        case 6: problem6();break;
        case 7: problem7();break;
            default:;
        };
    }while(inN<8);
    return 0;
}

//Menu Function
void Menu(){
    cout<<"Type 1 for problem 1"<<endl;
    cout<<"Type 2 for problem 2"<<endl;
    cout<<"Type 3 for problem 3"<<endl;
    cout<<"Type 4 for problem 4"<<endl;
    cout<<"Type 5 for problem 5"<<endl;
    cout<<"Type 6 for problem 6"<<endl;
    cout<<"Type 7 for problem 7"<<endl;
    cout<<"Type 8 to exit \n"<<endl;
}

//Choose problem number function
int getN(){
    int inN;
    cin>>inN;
    return inN;
}

//Solution to problem 1
void problem1(){
    cout<<"In Gaddis 8th Ed. Chap 7 problem # 1"<<endl<<endl;
     //Declare Variables
    const int SIZE=10;          //Array size
    int array[SIZE];            //array
    int min, max;           //minimum and maximum
    
    //Output
    cout<<"Enter 10 integers."<<endl;
    
    //Loop for numbers
    for(int i=0;i<SIZE;i++){
      
        cout<<"Number..."<<i+1<<endl;           //Enter 10 integers
        cin>>array[i];
        
        //Initialize max and min
        max=array[0];
        min=array[0];
        
        //Find Minimum
        for(int j=0;j<SIZE;j++){
         if (array[j]<=min){
            min=array[j];
        }
    
        //Finds the maximum
        if (array[j]>=max){
            max=array[j];
        }
       }
    }
    cout<<"The minimum is "<<min<<endl;
    cout<<"The maximum is "<<max;
}

//Solution to problem 2
void problem2(){
    cout<<"In Gaddis 8th Ed. Chap 7 problem # 2"<<endl<<endl;
     //Declare Variables
    const int SIZE=12;          //Array size
    float array[SIZE];            //array
    int min, max;           //minimum and maximum
    float average; 
    int sum=0;       //Find average
    
    //Output
    cout<<"Enter each total rainfall for each month of the year"<<endl;
    
    //Loop for numbers
    for(int i=0;i<SIZE;i++){
      
        cout<<"Month "<<i+1<<endl;           //Enter 10 integers
        cin>>array[i];
        
        //Initialize max and min
        max=array[0];
        min=array[0];
        
        //Find Average
       
           
        //Find Minimum
    }
    for(int j=0;j<SIZE;j++){
                if (array[j]<=min){
                min=array[j];
                }
    
                //Finds the maximum
                if (array[j]>=max){
                  max=array[j];
                }
        
       }
          for (int k=0;k<SIZE;k++){
                sum+=array[k];
          }
           average=static_cast<float>(sum)/SIZE;
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Total rainfall for the year is "<<sum<<endl;
    cout<<"The average rainfall is "<<average<<endl;
    cout<<"The minimum rainfall is "<<min<<endl;
    cout<<"The maximum rainfall is "<<max;

}

//Solution to problem 3
void problem3(){
    cout<<"In Gaddis 8thEd Chap7 problem # 3"<<endl<<endl;
    
    //Declare Variables
    const int SIZE=5;
    string salsa[SIZE]{"Mild","Medium","Sweet","Hot","Zesty"};  //Salsas
    int jar[SIZE];                      //Jars sold for each salsa
    int sum=0;                          //total of jars sold
   
    //Input Jars sold
    for(int i=0;i<SIZE;i++){
        cout<<"How many jars of "<<salsa[i]<<" were sold? "<<endl;
        cin>>jar[i];
    }
     int min=jar[0];            //minimum for jars
     int max=jar[0];            //maximum for jars
     int maxPos;                //position for max jars
     int minPos;                //position for min jars
     
    for(int j=0;j<SIZE;j++){
       //Find Minimum
         if (jar[j]<=min){ 
            min=jar[j];
            minPos=j;
        }
        //Finds the maximum
        if (jar[j]>=max){
            max=jar[j];
            maxPos=j;
        }
    }   
     for (int k=0;k<SIZE;k++){
         sum+=jar[k];           //Find total sum
         //Output Sauce and jar amount
         cout<<salsa[k]<<" sauce jars sold = "<<jar[k]<<endl;
         
     }
     //Output
    cout<<"The total amount of items sold is "<<sum<<endl;
    cout<<"The most sauce that was sold is "<<salsa[maxPos]<<endl;
    cout<<"The least sauce that was sold is "<<salsa[minPos]<<endl;
}

//Solution to problem 4
void problem4(){
    cout<<"In Gaddis 8th Ed Chap 7 problem # 4"<<endl<<endl;
    //Declare Variables
    const int SIZE=10;          //Array size
    int array[SIZE]{7,100,68,4,11,22,53,88,15,72}; 
    int number;
    
    //Input n
    cout<<"Enter an integer between 1 and 100...";
    cin>>number;
    
    fnctn(array,SIZE,number);
}

//Solution to problem 5
void problem5(){
    cout<<"In problem # 5"<<endl<<endl;
}

//Solution to problem 6
void problem6(){
    cout<<"Gaddis 8thEd Chap 7, problem # 12"<<endl<<endl;
    
    //Declare and Initialize array
    const int STUDENT=5,  //Number of students
              GRADES=5,   //Number of grades
              SCORES=4;   //Number of test scores
    string names[STUDENT];//student names
    char letGrad[GRADES]={'F','D','C','B','A'}; //grades
    float stuScre[STUDENT][SCORES];
    float sumStu[STUDENT];
    
    //Declare variables
    float avg;  //average of each test score per student
    
    //Input names and scores
    for(int i=0;i<STUDENT;i++){
        int sum=0;
        cout<<"Enter name of student "<<i+1<<": ";
        cin>>names[i];
        for(int j=0;j<SCORES;j++){
            do{
            cout<<names[i]<<": Score "<<j+1<<": ";
            cin>>stuScre[i][j];
            if(stuScre[i][j]==0){
                    cout<<"You got a zero?!?!?! Get a life!"<<endl;
                }
            if(stuScre[i][j]<0 || stuScre[i][j]>100){
                cout<<"A test score cannot be less than 0 or greater than 100"<<endl<<endl;
            }
            }while(stuScre[i][j]<0 || stuScre[i][j]>100);
            sum+=stuScre[i][j];
        }
        sumStu[i]=sum;
    }
    cout<<endl;
    
    //Output grade
    for(int i=0;i<STUDENT;i++){
        avg=sumStu[i]/4;
        cout<<names[i]<<"'s Grade: ";
        if(avg>=90) cout<<"Average: "<<avg<<"% "<<letGrad[4]<<endl;
        else if(avg>=80) cout<<"Average: "<<avg<<"% "<<letGrad[3]<<endl;
        else if(avg>=70) cout<<"Average: "<<avg<<"% "<<letGrad[2]<<endl;
        else if(avg>=60) cout<<"Average: "<<avg<<"% "<<letGrad[1]<<endl;
        else cout<<"Average: "<<avg<<"% "<<letGrad[0]<<endl;
    }
    cout<<endl;
}


//Solution to problem 7
void problem7(){
    cout<<"In Gaddis 8th Ed. Chap 7 problem # 13"<<endl<<endl;
    
    //Initialize the array
    const int STUDENT=5,                        //number of students
              GRADES=5,                         //number of grades
              SCORES=4;                         //number of scores
    string names[STUDENT];                      //student names
    char letGrad[GRADES]={'F','D','C','B','A'}; //array of letter grades
    float stuScre[STUDENT][SCORES];
    float sumStu[STUDENT];
    
    //Declare and Initialize variables
    float avg;                      //average of score per student
    int   min=100;                  //minimum score
    
    //Input names and scores
    for(int i=0;i<STUDENT;i++){
        int sum=0;
        cout<<"Enter name of student "<<i+1<<": ";
        cin>>names[i];
        for(int j=0;j<SCORES;j++){
            do{
            cout<<names[i]<<": Score "<<j+1<<": ";
            cin>>stuScre[i][j];
            if(stuScre[i][j]<min){
                min=stuScre[i][j];
            }
            if(stuScre[i][j]==0){
                    cout<<"You got a zero?!?!?! Get a life!"<<endl;
                }
            if(stuScre[i][j]<0 || stuScre[i][j]>100){
                cout<<"A test score cannot be less than 0 or greater than 100"<<endl<<endl;
            }
            }while(stuScre[i][j]<0 || stuScre[i][j]>100);
            sum+=stuScre[i][j];
        }
        sum-=min;
        sumStu[i]=sum;
    }
    cout<<endl;
    
    //Output grades
    for(int i=0;i<STUDENT;i++){
        avg=sumStu[i]/3;
        cout<<names[i]<<"'s Grade with lowest test score dropped: ";
        if(avg>=90) cout<<"Average: "<<avg<<"% "<<letGrad[4]<<endl;
        else if(avg>=80) cout<<"Average: "<<avg<<"% "<<letGrad[3]<<endl;
        else if(avg>=70) cout<<"Average: "<<avg<<"% "<<letGrad[2]<<endl;
        else if(avg>=60) cout<<"Average: "<<avg<<"% "<<letGrad[1]<<endl;
        else cout<<"Average: "<<avg<<"% "<<letGrad[0]<<endl;
    }
    cout<<endl;
}

//Exit Comment
void def(int inN){
    cout<<"You typed "<<inN<<" to exit the program"<<endl;
}

void fnctn(int a[],int s, int n){
    for (int i=0;i<s;i++){
        if (a[i]>n){
            cout<<a[i]<<endl;
        }
    }
}