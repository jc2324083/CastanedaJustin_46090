/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on June 29, 2015, 12:11 PM
 * Purpose: Male and Female Percentages
 */

// System Libraries
#include <iostream> // File I/O
using namespace std; // std namespace -> iostream

// User Libraries

// Global Constants
float CVSNPCT = 100; // Conversion for percentage
// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) 
{
    // Declare Variables Here
    float males;        //number of males
    float females;      //number of females
    float total;        //total number of students
    float pctmale;      //percentage of males
    float pctfmal;      //percentage of females
    
    // Input Values Here
    cout<<"Enter number of males in the classroom."<<endl;
    cin>>males;
    cout<<"Enter number of females in the classroom."<<endl;
    cin>>females;
    
    // Process Input Here
    total=males+females;                //total number of students
    pctmale=(males/total)*CVSNPCT;      //calculating percentage of males
    pctfmal=(females/total)*CVSNPCT;    //calculating percentage of females
    
    // Output Unknowns Here
    cout<<"With a total of "<<total<<" students,";
    cout<<"The class consist of %"<<pctmale<<" males and %"<<pctfmal<<" females."<<endl;
    //Exit Stage Right!
    return 0;
}
