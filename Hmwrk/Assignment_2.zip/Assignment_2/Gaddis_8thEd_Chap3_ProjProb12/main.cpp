/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 5, 2015, 7:32 PM
 * Purpose: Convert Currency
 */

// System Libraries
#include <iostream>     // File I/O
#include <iomanip>
using namespace std; // std namespace -> iostream

// User Libraries

// Global Constants
float EURPDOL=0.8235;        //Euros per dollar
float YENPDOL=78.18;        // Yen per dollar
// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short dollar;                  //US dollar
    unsigned short yen;                     //Yen currency
    unsigned short euros;                   //Euros currency
    
    //Input dollar
    cout<<"Enter the amount of US currency $";
    cin>>dollar;
    
    //Calculations
    yen=dollar*YENPDOL;                   //Conversion to YEN
    euros=dollar*EURPDOL;                 //Conversion to EUROS
    
    //Output Results
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"That will be "<<yen<<" Yen."<<endl;
    cout<<"That will be "<<euros<<" Euros."<<endl;

    return 0;
}

