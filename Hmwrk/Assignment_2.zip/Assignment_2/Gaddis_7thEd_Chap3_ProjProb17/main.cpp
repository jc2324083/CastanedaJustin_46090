/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 1, 2015, 11:01 AM
 * Purpose: Monthly payments on loans
 */
//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execute
int main(int argc, char** argv) {
    //Declare and Initialize variables
    float ir=0.01f;                     //Rate of the loan
    unsigned char numPay=36;            //Number of month with payment
    unsigned short loan=10000;          //Loan amount handed out
    float payment;                      //Monthly Payment
    float temp=1.0f;                    //temp for math equation
    float totCost;                      //Total paid back to lender
    float cstLoan;                      //Interest Paid
    
    //Calculate the intermediate value
    float onePlsi=(1+ir);
    for(int months=1;months<=numPay;months++){
        temp*=onePlsi;
    }
   
    //Calculate the monthly payment
    payment=ir*temp*loan/(temp-1);
    int imnthPay=payment*100;
    payment=imnthPay/100.0f;            //Exact amount in pennies
    totCost=numPay*payment;
    cstLoan=totCost-loan;
    
    //Output
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout<<"Loan Amount:           $"<<setw(8)<<loan*1.0f<<endl;
    cout<<"Monthly Interest Rate: "<<setw(8)<<ir*100<<"%"<<endl;
    cout<<"Number of Payments:     "<<setw(8)<<static_cast<int>(numPay)<<endl;
    cout<<"Monthly Payment:       $"<<setw(8)<<payment<<endl;
    cout<<"Amount Paid Back:      $"<<setw(8)<<totCost<<endl;
    cout<<"Interest Paid:         $"<<setw(8)<<cstLoan<<endl;
    
    //Exit
    return 0;
}

