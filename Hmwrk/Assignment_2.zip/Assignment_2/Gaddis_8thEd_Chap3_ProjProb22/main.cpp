/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 2, 2015, 11:02 PM
 * Purpose: Angle Calculator
 */

// System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std; 

// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    //Declare and Initialize Variables
    float angle;        //User's Angle
    float angsin;       //Sine Angle
    float angcos;       //Cosine Angle
    float angtan;       //Tangent Angle
    
    //Input angle
    cout<<"What is the angle? ";
    cin>>angle;
    
    //Calculations
    angsin=sin(angle);
    angcos=cos(angle);
    angtan=tan(angle);
    
    //Output Results
    cout<<fixed<<showpoint<<setprecision(4);
    cout<<"The sine for the angle is "<<angsin<<endl;
    cout<<"The cosine for the angle is "<<angcos<<endl;
    cout<<"The tangent for the angle is "<<angtan<<endl;
    
    return 0;
}

