/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 5, 2015, 4:19 PM
 * Purpose: Find out total sales of ticket
 */
// System Libraries
#include <iostream> // File I/O
#include <iomanip>
using namespace std; // std namespace -> iostream

// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!

int main(int argc, char** argv) {
    //Declare and Initialize Variables
    unsigned short classA=15;       //Tickets for class A $15
    unsigned short classB=12;       //Tickets for class b $12
    unsigned short classC=9;        //Tickets for class c $9
    float numA,numB,numC;           //Number of tickets purchased
    float totalA,totalB,totalC;     //Total price for tickets
    float totlAll;                  //Total of all tickets
    
    //Input tickets sold
    cout<<"How many Class A tickets? ";
    cin>>numA;
    cout<<"How many Class B tickets? ";
    cin>>numB;
    cout<<"How many Class C tickets? ";
    cin>>numC;
    
    //calculations
    totalA=numA*classA;             //Total price from sold ticket class a
    totalB=numB*classB;             //total price for class B
    totalC=numC*classC;             //total price for class C
    totlAll=totalA+totalB+totalC;   //total price from all classes
    
    //Output
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Total income earned is $"<<totlAll<<endl;
    
    
    return 0;
}

