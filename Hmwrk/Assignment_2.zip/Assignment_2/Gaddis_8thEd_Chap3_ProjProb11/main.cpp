/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 5, 2015, 4:44 PM
 * Purpose: Switch  Celsius to Fahrenheit
 */

// System Libraries
#include <iostream> // File I/O
#include <cmath>
using namespace std; 

// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float celsis;           //Celsius
    float fahiet;           //Fahrenheit
    float ninDfiv=9/5;      //Nine divided by five
    
    //Input
    cout<<"Inset Celsius ";
    cin>>celsis;
    
    //calculation
    fahiet=(ninDfiv*celsis)+32;
    
    //Output results
    cout<<celsis<<" degrees Celsius is converted to "<<fahiet<<" degrees Fahrenheit."<<endl;

    return 0;
}

