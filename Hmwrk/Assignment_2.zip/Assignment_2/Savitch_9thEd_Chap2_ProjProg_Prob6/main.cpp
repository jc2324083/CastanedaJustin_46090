/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 1, 2015, 1:09 PM
 * Purpose: Employee check
 */

//System Libraires
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constant

//Function Prototypes

//Execution!!
int main(int argc, char** argv) {
    float payRate=16.78;                //Employment Payment
    unsigned short hours;               //Hours worked
    float paybTax;                      //Payment before taxes
    float payaTax;                      //Payment after taxes
    float sst=0.06f;                    //Social Security Tax 6%
    float ssTake;                       //cost of SS tax
    float fedInTx=0.14f;                //Federal Income Tax 14%
    float fdTake;                       //cost of federal tax
    float stTake;                       //cost of state tax
    float stateTx=0.05f;                //State Tax
    float unin=10;                      //Union $10
    float totalTx;                      //Total take
    float kids;                         //dependents in household
    
    //Output Ask for hours
    cout<<"Enter hours for this week ---";
    cin>>hours;                         //Enter hours worked
    if (hours>40){                      //If hours exceed 40 hours      
        int ovrTime;                    //OverTime
        float ovrPay;                   //Overtime payment
        ovrTime=(hours-40);             //Hours to charge
        ovrPay=ovrTime*(payRate*1.5);   //How much employee gets paid
        paybTax=(40*payRate)+ovrPay;    //overtime pay + gross pay
    }else{
    //Calculate and Output Gross pay
    paybTax=payRate*hours;
    }
    cout<<"Payment without taxes is $"<<paybTax<<endl;
    
    //Initialize Children
    cout<<"How many dependents do you claim?---";
    cin>>kids;
   
    //Calculate and output Tax pay 
    ssTake=sst*paybTax;
    fdTake=fedInTx*paybTax;
    stTake=stateTx*paybTax;
    cout<<"Your Social Security Tax is $"<<ssTake<<endl;
    cout<<"Your Federal Income Tax is $"<<fdTake<<endl;
    cout<<"Your State Tax is $"<<stTake<<endl;
    cout<<"Your Union pay is $"<<unin<<endl;
    
    //If the employee claims 3 or more dependents
     if (kids>=3){
        float healthI=35;
        totalTx=ssTake+fdTake+stTake+unin+healthI;
        cout<<"Your Health Insurance payment is $"<<healthI<<endl;
    }else{
        totalTx=ssTake+fdTake+stTake+unin;
    }
   
    //Calculate and output Net Pay
    payaTax=paybTax-totalTx;
    cout<<"Your total payment with taxes is $"<<payaTax<<endl;
    
    

    return 0;
}

