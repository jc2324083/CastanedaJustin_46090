/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 5, 2015, 5:20 PM
 * Purpose: Calculating test average
 */

// System Libraries
#include <iostream>     
#include <iomanip>
using namespace std; // std namespace -> iostream

// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short test1,test2,test3,test4,test5;   //The 5 test scores
    unsigned short avrge;                           //Average of 5 scores
    
    //Input test scores
    cout<<"Please input first test score...";
    cin>>test1;
    cout<<"Please input second test score...";
    cin>>test2;
    cout<<"PLease input third test score...";
    cin>>test3;
    cout<<"Please input fourth test score...";
    cin>>test4;
    cout<<"Please input fifth test score...";
    cin>>test5;
    
    //Calculate average
    avrge=(test1+test2+test3+test4+test5)/5;
    
    //Output results
    cout<<fixed<<showpoint<<setprecision(1);
    cout<<"The average test score is "<<avrge<<endl;

    return 0;
}

