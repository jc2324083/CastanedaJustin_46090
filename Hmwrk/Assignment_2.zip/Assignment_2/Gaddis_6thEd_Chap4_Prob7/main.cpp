/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 2, 2015, 1:32 PM
 * Purpose: Days in a month
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constant

//Function Prototypes

//Execution!!
int main(int argc, char** argv) {
    //Declare Variables
    int numSecs;        //Amount of seconds
    int years;          //Years
    int months;         //months
    int weeks;          //weeks
    int days;           //days
    int hours;          //hours
    int mints;          //minutes
    int secds;          //seconds
    
    //Input number of seconds
    cout<<"How many seconds?"<<endl;
    cin>>numSecs;
    
    //Calculations
    secds=numSecs%60;   //How many seconds
    numSecs/=60;        //To minutes
    mints=numSecs%60;   //How many minutes
    numSecs/=60;        //To hours
    hours=numSecs%24;   //How many hours
    numSecs/=24;        //to days
    days=numSecs%7;     //How many days
    numSecs/=7;         //To weeks
    weeks=numSecs%4;    //How many weeks
    numSecs/=4;         //To Months
    months=numSecs%12;  //How many months
    years=numSecs/12;   //How many years
    
    //Output
    cout<<"The number of seconds is "<<secds<<endl;
    cout<<"The number of minutes is "<<mints<<endl;
    cout<<"The number of hours is "<<hours<<endl;
    cout<<"The number of days is "<<days<<endl;
    cout<<"The number of weeks is "<<weeks<<endl;
    cout<<"The number of months is "<<months<<endl;
    cout<<"The number of years is "<<years<<endl;

    return 0;
}

