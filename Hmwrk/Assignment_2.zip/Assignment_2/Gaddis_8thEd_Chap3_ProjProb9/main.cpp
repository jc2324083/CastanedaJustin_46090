/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 2, 2015, 10:23 AM
 * Purpose: How many Calories
 */
// System Libraries
#include <iostream> 
#include <cmath>
using namespace std; 

// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    //Declare and Initialize Variables
    int cookies;                //How many cookies consumed
    int calries;                //Calories consumed
    int calpcoo=30;             //Calories per cookies
    
    //Input cookies
    cout<<"How many cookies did you consumed? ";
    cin>>cookies;
    
    //Calculations
    calries=calpcoo*cookies;
    
    //Output Results
    cout<<"You have consumed "<<calries<<" calories. YUM!"<<endl;
    

    return 0;
}

