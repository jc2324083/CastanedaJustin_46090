/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 2, 2015, 12:10 PM
 * Purpose: Approximate Factorial
 */
//System Libraires
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constant

//Function Prototypes

//Execution!!
int main(int argc, char** argv) {
    //Declare our variables
    float x=2.0f;
    float ex=1.0f;
    char nTerms=30;
    
    //Utilize a for-loop to calculate e^x
    for(int term=1;term<=nTerms;term++){
        float fact=1;
        
        //Loop and find the n!
        for(int i=1;i<=term;i++){
            fact*=i;
        }
        ex+=pow(x,term)/fact;
    }
    //Output the result
    cout<<"Exact  e("<<x<<")="<<exp(x)<<endl;
    cout<<"Approx e("<<x<<")="<<ex<<endl;
    
    //Exit stage right
    return 0;
}


