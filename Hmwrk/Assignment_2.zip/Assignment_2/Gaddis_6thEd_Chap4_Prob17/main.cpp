
/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 2, 2015, 1:10 PM
 * Purpose: Spectral Analysis
 */

//System Libraires
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constant

//Function Prototypes

//Execution!!
int main(int argc, char** argv) {
    //Declare variables
    float waveLn;               //Wavelength
    
    //Input variables
    cout<<"Please enter wavelength via scientific notation (ex:1e-2)"<<endl;
    cin>>waveLn;
    
    //Output results of different wavelengths
   if (waveLn>1e-2){cout<<waveLn<<" is in the Radio Wave Spectral!"<<endl;}
   else if (waveLn>1e-3){cout<<waveLn<<" is in the Microwave Spectral!"<<endl;}
   else if (waveLn>7e-7){cout<<waveLn<<" is in the Infrared Spectral!"<<endl;}
   else if (waveLn>4e-7){cout<<waveLn<<" is in the Visible Light Spectral!"<<endl;}
   else if (waveLn>1e-8){cout<<waveLn<<" is in the Ultraviolet Spectral!"<<endl;}
   else if (waveLn>1e-11){cout<<waveLn<<" is in the X-Ray Spectral!"<<endl;}
   else if (waveLn<=1e-11){cout<<waveLn<<" is in the Gamma Ray Spectral!"<<endl;}
    
    
    
    
    //Exit stage right
    return 0;
}