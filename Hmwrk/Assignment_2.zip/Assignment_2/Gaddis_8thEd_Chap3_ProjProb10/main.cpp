/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 3, 2015, 10:35 AM
 * Purpose: How Much Insurance
 */

// System Libraries
#include <iostream>
#include <cmath>
using namespace std; 

// User Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    //Declare and Initialize Variables
    float insure=0.80f;         //80% Insurance
    float housect;              //Price in house
    float cost;                 //Recommendation minimum amount
    
    //Input house cost
    cout<<"How much would it cost to replace structure? $";
    cin>>housect;
    
    //Calculations
    cost=insure*housect;
    
    //Output the results
    cout<<"The suggested amount for insurance is $"<<cost<<endl;

    return 0;
}

