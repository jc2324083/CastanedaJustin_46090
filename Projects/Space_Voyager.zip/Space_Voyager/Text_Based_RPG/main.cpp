/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 7, 2015, 10:45 AM
 * Purpose: Text Based RPG
 */
//System Libraries
#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;
//User Libraries

//Global Constant

//Function Prototypes
int cStatus(int,int,int);
int mStatus(int,int,int);

//Engage!
int main(int argc, char** argv) {
    //Declare and Initialize Variables
    int hp=150;             //User's Starting Health Power
    int gp=50;              //User's Starting Gun Power
    int nc=3;               //Number of Nova Crystal Shards
    int monHP=400;          //Monster's Starting Health Points
    int monMP=100;          //Monster's Starting Dark Matter Points
    int command;            //Inputting command
    
    //Output Game Intro
    cout<<"\t\t******Space Voyager******"<<endl;
    cout<<"You received a distress signal from a ground station on Planet Bree "<<endl;
    cout<<"from the Alpha Centauri star system. When arriving you find the ground station "<<endl;
    cout<<"was under attacked. Upon further searching you find a survivor on their last breath, "<<endl<<endl;
    cout<<"Survivor:A CREATURE DID THIS!! It came from the valley and attacked us."<<endl;
    cout<<"It must of came for our resources for energy. It thrives from the Nova Crystals "<<endl;
    cout<<"that we are mining here."<<endl<<endl;
    cout<<"Filled with rage you head out into the valley for revenge and encounter the creature."<<endl<<endl;
    cout<<"All you have is your Galatic Gun and 3 Nova Crystal Shards(recovers 50 HP and 15 GP)"<<endl;
    cout<<"Select 1 to Attack, Select 2 to use Nova Crystal Shard, Select 3 to use Charged Cannon"<<endl;
    cout<<"Input command...";
    cin>>command;
    
    //Command 1
    if (command==1){
        
    }
    
    
    

    return 0;
}

int cStatus(int h,int g, int n){
    cout<<"Your HP is "<<h<<"/150"<<endl;
    cout<<"Your GP is "<<g<<"/50"<<endl;
}