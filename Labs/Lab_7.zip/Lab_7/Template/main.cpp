/* 
 * File:   main.cpp
 * Author: Justin Castaneda
 * Created on July 14, 2015, 12:12 PM
 * Purpose:
 */
//System Libraries
#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
int example(int a,int &b);

//Engage!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize and Prompt for inputs
    
    //Process the inputs
    
    //Output the results
    
    //Exit
    return 0;
}
/***************************************************************************
 *                                  Example                                *
 * 
 ***************************************************************************/
int example(int a,int &b){
    //Declare a variable c
    int c;
    //Process
    
    //Output
}